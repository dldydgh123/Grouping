$(function () {

  if ( $('.container').hasClass('write') ) {
    new WritePost();
  }

});