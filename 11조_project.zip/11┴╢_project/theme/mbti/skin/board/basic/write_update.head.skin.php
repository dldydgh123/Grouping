<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가
$wr_6 = "$op1[0]|$op1[1]|$op1[2]|$op1[3]|$op1[4]|$op1[5]|$op1[6]|$op1[7]|$op1[8]|$op1[9]|$op1[10]|$op1[11]|$op1[12]|$op1[13]";
sql_query(" update $write_table set wr_6 = '$wr_6' where wr_id = '$wr_id' ");
?>