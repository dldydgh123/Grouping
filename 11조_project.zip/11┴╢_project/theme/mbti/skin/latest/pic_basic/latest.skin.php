<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가
include_once(G5_LIB_PATH.'/thumbnail.lib.php');

// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨
add_stylesheet('<link rel="stylesheet" href="'.$latest_skin_url.'/style.css">', 0);
$thumb_width = 600;
$thumb_height = 600;
?>

<div class="pic_lt">
    <ul class="row">
    <?php
    for ($i=0; $i<count($list); $i++) {
    $thumb = get_list_thumbnail($bo_table, $list[$i]['wr_id'], $thumb_width, $thumb_height, false, true);

    if($thumb['src']) {
        $img = $thumb['src'];
    } else {
        $img = G5_IMG_URL.'/no_img.png';
    }
    $img_content = '<img src="'.$img.'" alt="'.$thumb['alt'].'" width="'.$thumb_width.'" height="'.$thumb_height.'">';
    ?>
        <li class="col-md-3 col-sm-6">
			<div class="pic-box">
			
            <a href="<?php echo $list[$i]['href'] ?>" class="lt_img"><?php echo $img_content; ?></a>
			  <div class="gy_img">				
			
				<?php 
				if ($list[$i]['wr_8'] == '0') {
					echo "<img src='$latest_skin_url/img/re_top1.gif'>";
					} 
				elseif ($list[$i]['wr_8'] == '1') {
					echo "<img src='$latest_skin_url/img/re_top2.gif'>";
				}

				elseif ($list[$i]['wr_8'] == '2') {
					echo "<img src='$latest_skin_url/img/re_top3.gif'>";
				}			

				?>
	
			  </div>	
				<div class="pic-txt">
					<a href="<?php echo $list[$i]['href'] ?>">				  
					<?php
					echo "<h4>";
					if ($list[$i]['icon_secret']) echo "<i class=\"fa fa-lock\" aria-hidden=\"true\"></i><span class=\"sound_only\">비밀글</span> ";

					if ($list[$i]['is_notice'])
						echo "<strong>".$list[$i]['subject']."</strong>";
					else
						echo $list[$i]['subject'];

					echo "</h4>";

					?>
					</a>	
			    </div><!--pic-txt-->
			  
				<div class="pic-txt2">				
					<a href="<?php echo $list[$i]['href'] ?>">	
					  <p class="pic_txt2_p1"><?php echo cut_str(strip_tags($list[$i]['wr_6']), 65); ?></p>
					  <p class=""><?php echo cut_str(strip_tags($list[$i]['wr_7']), 65); ?></p>
					</a>
			     </div>
		    
		  </div><!--pic-box-->
        </li>
    <?php }  ?>
    <?php if (count($list) == 0) { //게시물이 없을 때  ?>
    <li class="empty_li col-md-12">게시물이 없습니다.</li>
    <?php }  ?>


    </ul>

<?php if ($is_admin) {  ?>
<a class="admin_btn" href="<?php echo G5_BBS_URL ?>/board.php?bo_table=<?php echo $bo_table ?>">관리자</a>
<?php }  ?>

</div>
           

