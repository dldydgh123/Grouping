<?php
define('_INDEX_', true);
include_once('./_common.php');
require_once(G5_BBS_PATH.'/board.php');
return;
?>

<?php
include_once(G5_THEME_PATH.'/tail.php');
?>